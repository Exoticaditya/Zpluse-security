package com.sgms.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import javax.sql.DataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

@Configuration
@Profile("prod")
public class DatabaseConfig {

  @Bean
  @ConfigurationProperties(prefix = "spring.datasource.hikari")
  public HikariConfig hikariConfig() {
    return new HikariConfig();
  }

  @Bean
  public DataSource dataSource(HikariConfig hikariConfig, Environment environment) {
    String databaseUrl = environment.getProperty("DATABASE_URL");
    if (databaseUrl == null || databaseUrl.isBlank()) {
      throw new IllegalStateException("DATABASE_URL environment variable is required for prod profile");
    }

    ParsedDatabaseUrl parsed = parseDatabaseUrl(databaseUrl);

    hikariConfig.setDriverClassName("org.postgresql.Driver");
    hikariConfig.setJdbcUrl(parsed.jdbcUrl());
    hikariConfig.setUsername(parsed.username());
    hikariConfig.setPassword(parsed.password());

    return new HikariDataSource(hikariConfig);
  }

  private ParsedDatabaseUrl parseDatabaseUrl(String databaseUrl) {
    URI uri;
    try {
      uri = new URI(databaseUrl);
    } catch (URISyntaxException e) {
      throw new IllegalArgumentException("Invalid DATABASE_URL", e);
    }

    if (uri.getScheme() == null || !uri.getScheme().startsWith("postgres")) {
      throw new IllegalArgumentException("DATABASE_URL must start with postgresql://");
    }

    String host = uri.getHost();
    int port = uri.getPort();
    String path = uri.getPath();
    if (host == null || host.isBlank() || port <= 0 || path == null || path.isBlank()) {
      throw new IllegalArgumentException("DATABASE_URL must include host, port, and database name");
    }

    String dbName = path.startsWith("/") ? path.substring(1) : path;

    String userInfo = uri.getUserInfo();
    if (userInfo == null || !userInfo.contains(":")) {
      throw new IllegalArgumentException("DATABASE_URL must include username and password");
    }
    String[] parts = userInfo.split(":", 2);
    String username = urlDecode(parts[0]);
    String password = urlDecode(parts[1]);

    String jdbcUrl = "jdbc:postgresql://" + host + ":" + port + "/" + dbName;
    return new ParsedDatabaseUrl(jdbcUrl, username, password);
  }

  private String urlDecode(String value) {
    return URLDecoder.decode(value, StandardCharsets.UTF_8);
  }

  private record ParsedDatabaseUrl(String jdbcUrl, String username, String password) {}
}
